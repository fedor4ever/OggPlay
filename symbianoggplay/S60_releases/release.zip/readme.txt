This is the README for Release 0.97 of Oggplay for Series60.

For more information about Oggplay, please see the webpage at
http://www.geocities.com/p800tools/

Please uninstall the old release 0.96 before installing the current
release.

Installation:
Install the OggPlay_s60.SIS to your phone.

New in this release:

o Navigation scheme completely revamped to be more S60-like.
o Better audio buffer handling.
o Skin functionality, create your own skin!
o 2 New skins.
o Experimental fast forward and reverse, currently mapped to keys '1'
and '6' respectively.

o Recognizer support: Just click on an .ogg file in any filebrowser and
that file starts playing in Oggplay. For that functionality, you need to 
install the separate Ogg_recognizer.sis. Note: due to a firmware bug we 
had to restrict the installation to a MMC.  

OggPlay has been tested on Siemens SX-1 and on Nokia NGage. It should be
functional on following Nokia phones : 7650, 3650 and 6600. Pless inform us
about your OggPlay experience with the phones we couldn't test!
 

Thanks to everyone involved in Oggplay, especially to Lars Wilden for
releasing it under the GPL.

Stay tuned for more...

-the S60 Oggplay developers.
//# Version String
This is the README for Release 0.98 of Oggplay for Series60.

For more information about Oggplay, please see the webpage at
http://www.geocities.com/p800tools/

Installation:
If you have release older than 0.97 installed on your phone, please uninstall
it before installing the current release.
Install the OggPlay_s60.SIS to your phone.

New in this release:
o Now Compatible with Nokia 6600

Some 'nice to know' features of OggPlay:
o Skin functionality, create your own skin!
o Fast forward and reverse, currently mapped to keys '1'
and '6' respectively.

o Recognizer support: Just click on an .ogg file in any filebrowser and
that file starts playing in Oggplay. For that functionality, you need to 
install the separate Ogg_recognizer.sis. Note: due to a firmware bug we 
had to restrict the installation to a MMC.  

OggPlay has been tested on Siemens SX-1, Nokia NGage and Nokia 6600. 
It should be functional on following Nokia phones : 7650, 3650.
Please inform us about your OggPlay experience with the phones we
couldn't test!
 

Thanks to everyone involved in Oggplay, especially to Lars Wilden for
releasing it under the GPL.

Stay tuned for more...

-the S60 Oggplay developers.
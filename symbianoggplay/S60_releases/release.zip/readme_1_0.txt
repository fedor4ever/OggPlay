This is the README for Release 1.0 of Oggplay for Series60.

For more information about Oggplay, please see the webpage at
http://www.geocities.com/p800tools/

For help and open discussion about OggPlay see under 'Public Forums' on
http://sourceforge.net/projects/symbianoggplay/

There are two seperate installs :
Oggplay.S60.sis - OggPlay application.
Recognizer.S60.sis - OggPlay recognizer. Optional.
Lets the operating system launch OggPlay if a 'open file' is executed
on a .Ogg file in for instance the inbox or in a file browser application.
Note: due to a firmware bug the installation is restricted to be on MMC only.  

OggPlay has been tested on Siemens SX-1, Nokia NGage and Nokia 6600 but should
work on all Series 60 phones. Please report any problems on the sourceforge
forums found via the link above.

-the S60 Oggplay developers.